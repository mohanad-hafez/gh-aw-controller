set -euo pipefail
mkdir -p /tmp/gh-aw/agent

# Read thresholds from .architecture.yml or use defaults
FILE_LINES_BLOCKER=1000
FILE_LINES_WARNING=500
FUNCTION_LINES=80
MAX_EXPORTS=10

if [ -f .architecture.yml ]; then
  b=$(grep -E '^\s*file_lines_blocker:' .architecture.yml 2>/dev/null | awk '{print $2}' | tr -d '"' | head -1 || true)
  w=$(grep -E '^\s*file_lines_warning:' .architecture.yml 2>/dev/null | awk '{print $2}' | tr -d '"' | head -1 || true)
  f=$(grep -E '^\s*function_lines:' .architecture.yml 2>/dev/null | awk '{print $2}' | tr -d '"' | head -1 || true)
  e=$(grep -E '^\s*max_exports:' .architecture.yml 2>/dev/null | awk '{print $2}' | tr -d '"' | head -1 || true)
  [[ -n "${b:-}" && "$b" =~ ^[0-9]+$ ]] && FILE_LINES_BLOCKER=$b
  [[ -n "${w:-}" && "$w" =~ ^[0-9]+$ ]] && FILE_LINES_WARNING=$w
  [[ -n "${f:-}" && "$f" =~ ^[0-9]+$ ]] && FUNCTION_LINES=$f
  [[ -n "${e:-}" && "$e" =~ ^[0-9]+$ ]] && MAX_EXPORTS=$e
fi

# Get changed Go/JS files in last 24 hours, excluding tests and vendor paths
CHANGED_FILES=$(git log --since="24 hours ago" --name-only --pretty=format: \
  | sort -u \
  | grep -E '\.(go|js|cjs|mjs)$' \
  | grep -vE '(node_modules/|vendor/|\.git/|_test\.go$)' \
  | while IFS= read -r f; do [ -f "$f" ] && echo "$f"; done \
  || true)

if [ -z "$CHANGED_FILES" ]; then
  jq -n \
    --argjson blocker "$FILE_LINES_BLOCKER" \
    --argjson warning "$FILE_LINES_WARNING" \
    --argjson func_lines "$FUNCTION_LINES" \
    --argjson max_exports "$MAX_EXPORTS" \
    '{noop: true, thresholds: {file_lines_blocker: $blocker, file_lines_warning: $warning, function_lines: $func_lines, max_exports: $max_exports}, files: [], import_cycles: ""}' \
    > /tmp/gh-aw/agent/arch-metrics.json
  echo "No changed Go/JS files found in the last 24 hours."
  exit 0
fi

# Build file metrics array
FILES_JSON="[]"
while IFS= read -r FILE; do
  [ -z "$FILE" ] && continue
  LINES=$(wc -l < "$FILE" 2>/dev/null | tr -d ' ' || echo 0)
  EXT="${FILE##*.}"

  if [[ "$EXT" == "go" ]]; then
    # Function sizes: "func declaration\tline_count" per function
    # Pattern matches both regular functions (^func Name) and receiver methods (^func (r *T) Name)
    FUNC_DATA=$(awk '/^func /{if(start>0 && name!="") printf "%s\t%d\n", name, NR-start; name=$0; start=NR} END{if(start>0 && name!="") printf "%s\t%d\n", name, NR-start+1}' "$FILE" 2>/dev/null | head -50 || true)
    # Export count and names (top-level exported identifiers start with uppercase)
    EXPORT_COUNT=$(grep -cE "^func [A-Z]|^type [A-Z]|^var [A-Z]|^const [A-Z]" "$FILE" 2>/dev/null || test "$?" -eq 1)
    EXPORT_NAMES=$(grep -nE "^func [A-Z]|^type [A-Z]|^var [A-Z]|^const [A-Z]" "$FILE" 2>/dev/null | head -20 || true)
  else
    # JS/CJS/MJS: capture named functions, arrow functions, and class methods
    FUNC_DATA=$(grep -nE "^function |^const [a-zA-Z_$][a-zA-Z0-9_$]* = (function|\(|async \(|async function)|^(export (default )?function|export const [a-zA-Z_$][a-zA-Z0-9_$]* =)|^[a-zA-Z_$][a-zA-Z0-9_$]*\s*\([^)]*\)\s*\{" "$FILE" 2>/dev/null | head -50 || true)
    CJS_COUNT=$(grep -cE "^module\.exports|^exports\." "$FILE" 2>/dev/null || test "$?" -eq 1)
    ESM_COUNT=$(grep -cE "^export " "$FILE" 2>/dev/null || test "$?" -eq 1)
    EXPORT_COUNT=$((CJS_COUNT + ESM_COUNT))
    EXPORT_NAMES=$(grep -nE "^export |^module\.exports|^exports\." "$FILE" 2>/dev/null | head -20 || true)
  fi

  FILES_JSON=$(jq \
    --arg file "$FILE" \
    --argjson lines "$LINES" \
    --argjson exports "$EXPORT_COUNT" \
    --arg func_data "${FUNC_DATA:-}" \
    --arg export_names "${EXPORT_NAMES:-}" \
    '. + [{file: $file, lines: $lines, export_count: $exports, func_data: $func_data, export_names: $export_names}]' \
    <<< "$FILES_JSON")
done <<< "$CHANGED_FILES"

# Check Go import cycles once across all packages
# Note: go list may also emit errors for syntax issues; grep filters to only cycle errors
IMPORT_CYCLES=$(go list ./... 2>&1 | grep -iE "import cycle|cycle not allowed" || true)

jq -n \
  --argjson blocker "$FILE_LINES_BLOCKER" \
  --argjson warning "$FILE_LINES_WARNING" \
  --argjson func_lines "$FUNCTION_LINES" \
  --argjson max_exports "$MAX_EXPORTS" \
  --argjson files "$FILES_JSON" \
  --arg import_cycles "$IMPORT_CYCLES" \
  '{noop: false, thresholds: {file_lines_blocker: $blocker, file_lines_warning: $warning, function_lines: $func_lines, max_exports: $max_exports}, files: $files, import_cycles: $import_cycles}' \
  > /tmp/gh-aw/agent/arch-metrics.json

FILE_COUNT=$(echo "$CHANGED_FILES" | wc -l | tr -d ' ')
echo "✅ Pre-computed metrics for $FILE_COUNT file(s) → /tmp/gh-aw/agent/arch-metrics.json"
