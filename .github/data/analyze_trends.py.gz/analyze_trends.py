#!/usr/bin/env python3
"""
Analyze benchmark trends and detect performance regressions
"""
import json
import os
import statistics
from datetime import datetime, timedelta
from pathlib import Path

# Configuration
HISTORY_FILE = '/tmp/gh-aw/repo-memory/default/benchmark_history.jsonl'
CURRENT_FILE = '/tmp/gh-aw/agent/benchmarks/current_metrics.json'
OUTPUT_FILE = '/tmp/gh-aw/agent/benchmarks/analysis.json'

# Bounded context window — must match MAX_HISTORY_ENTRIES in the bash pruning step
MAX_HISTORY_ENTRIES = 14

# Regression thresholds
REGRESSION_THRESHOLD = 1.10  # 10% slower is a regression
WARNING_THRESHOLD = 1.05     # 5% slower is a warning

# Environment-noise detection: when most unrelated benchmarks regress at once, the
# runner was almost certainly noisy (shared/overloaded CI host), not the code.
NOISE_MIN_REGRESSIONS = 3    # need at least this many regressions to suspect noise
NOISE_REGRESSION_RATIO = 0.5 # ...covering at least this fraction of all benchmarks

def load_history():
    """Load historical benchmark data — capped at last MAX_HISTORY_ENTRIES entries to bound context size"""
    history = []
    if os.path.exists(HISTORY_FILE):
        with open(HISTORY_FILE, 'r') as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        history.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
    # Keep only the most recent entries (bounded context window)
    return history[-MAX_HISTORY_ENTRIES:] if len(history) > MAX_HISTORY_ENTRIES else history

def load_current():
    """Load current benchmark results"""
    with open(CURRENT_FILE, 'r') as f:
        return json.load(f)

def analyze_benchmark(name, current_ns, history_data):
    """Analyze a single benchmark for regressions"""
    # Get historical values for this benchmark
    historical_values = []
    for entry in history_data:
        if 'benchmarks' in entry and name in entry['benchmarks']:
            historical_values.append(entry['benchmarks'][name]['ns_per_op'])
    
    if len(historical_values) < 2:
        return {
            'status': 'baseline',
            'message': 'Not enough historical data for comparison',
            'current_ns': current_ns,
            'avg_historical_ns': None,
            'change_percent': 0
        }
    
    # Use the median of recent history (last 7 data points) as the baseline —
    # the median is far less sensitive to one-off noisy runs than the mean
    recent_history = historical_values[-7:] if len(historical_values) >= 7 else historical_values
    avg_historical = statistics.median(recent_history)
    
    # Calculate change percentage
    change_percent = ((current_ns - avg_historical) / avg_historical) * 100
    
    # Determine status
    if current_ns > avg_historical * REGRESSION_THRESHOLD:
        status = 'regression'
        message = f'⚠️ REGRESSION: {change_percent:.1f}% slower than historical average'
    elif current_ns > avg_historical * WARNING_THRESHOLD:
        status = 'warning'
        message = f'⚡ WARNING: {change_percent:.1f}% slower than historical average'
    elif current_ns < avg_historical * 0.95:
        status = 'improvement'
        message = f'✅ IMPROVEMENT: {change_percent:.1f}% faster than historical average'
    else:
        status = 'stable'
        message = f'✓ STABLE: {change_percent:.1f}% change from historical average'
    
    return {
        'status': status,
        'message': message,
        'current_ns': current_ns,
        'avg_historical_ns': int(avg_historical),
        'change_percent': round(change_percent, 2),
        'data_points': len(historical_values)
    }

def main():
    # Load data
    history = load_history()
    current = load_current()
    
    # Analyze each benchmark
    analysis = {
        'timestamp': current['timestamp'],
        'date': current['date'],
        'benchmarks': {},
        'summary': {
            'total': 0,
            'regressions': 0,
            'warnings': 0,
            'improvements': 0,
            'stable': 0
        }
    }
    
    for name, metrics in current['benchmarks'].items():
        result = analyze_benchmark(name, metrics['ns_per_op'], history)
        analysis['benchmarks'][name] = result
        analysis['summary']['total'] += 1
        
        if result['status'] == 'regression':
            analysis['summary']['regressions'] += 1
        elif result['status'] == 'warning':
            analysis['summary']['warnings'] += 1
        elif result['status'] == 'improvement':
            analysis['summary']['improvements'] += 1
        elif result['status'] == 'stable':
            analysis['summary']['stable'] += 1
    
    # Detect likely environment noise: many unrelated benchmarks slowing down in the
    # same run points at a noisy runner rather than a real code regression.
    # Warnings count as degraded too, since noise spreads unevenly across benchmarks.
    summary_counts = analysis['summary']
    regressions = summary_counts['regressions']
    degraded = regressions + summary_counts['warnings']
    total = summary_counts['total']
    likely_noise = (
        regressions >= NOISE_MIN_REGRESSIONS
        and total > 0
        and degraded / total >= NOISE_REGRESSION_RATIO
    )
    analysis['summary']['likely_environment_noise'] = likely_noise

    # Save analysis
    with open(OUTPUT_FILE, 'w') as f:
        json.dump(analysis, f, indent=2)
    
    summary = analysis['summary']
    print(f"Analysis complete! total={summary['total']} regressions={summary['regressions']} warnings={summary['warnings']} improvements={summary['improvements']} likely_environment_noise={summary['likely_environment_noise']}")

if __name__ == '__main__':
    main()
